
import { useContext } from 'react'
import UserContext from '../contexts/UserContext'

function JeopardyScoreBoard({ score, question }) {
    const user = useContext(UserContext)

    console.log(user)

    return (
        <div>
            <h3>Jeopardy!</h3>

            <h3>Score: {score}</h3>

            <h4>Category: {question.category?.title}</h4>

            <h5>Question: {question.question}</h5>
        </div>
    )
}

export default JeopardyScoreBoard