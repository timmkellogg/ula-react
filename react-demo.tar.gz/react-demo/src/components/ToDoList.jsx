import { useState } from 'react'
import ToDo from './ToDo'

function ToDoList({ name }) {
    const [toDos, setToDos] = useState([{text: 'learn react', completed: false}, {text: 'have fun', completed: true }])
    const [input, setInput] = useState('')

    const addToDo = (event) => {
        event.preventDefault()

        if(!input.trim()) return
        
        const newToDos = [...toDos, { text: input, completed: false }]

        setToDos(newToDos)
        setInput('')
    }

    const toggleToDo = (index) => {
        const updatedToDos = [...toDos]

        updatedToDos[index].completed = !updatedToDos[index].completed

        setToDos(updatedToDos)
    }

    const deleteToDo = (event, index) => {
        event.stopPropagation()
        
        const updatedToDos = [...toDos]
        console.log(event.target)
        updatedToDos.splice(index, 1)

        setToDos(updatedToDos)
        
    }

    return (
        <div>
            <h3>Welcome to {name}'s To-Do List</h3>
            <form onSubmit={addToDo}>
                <input value={input} onChange={(event) => setInput(event.target.value)} />
                <button>add todo</button>
            </form>
            <ul>
               {toDos.map((item, key) => {
                return (
                    // <li onClick={() => toggleToDo(key)} key={key} id={key} style={{ textDecoration: item.completed ? 'line-through' : undefined }}>
                    //     c
                    //     <button onClick={(event) => deleteToDo(event, key)}>remove</button>
                    // </li>
                    <ToDo item={item} key={key} index={key} toggleToDo={toggleToDo} deleteToDo={deleteToDo}  />
                )
               })}
            </ul>
        </div>
    )
}

export default ToDoList