import { useEffect, useState } from 'react'
import JeopardyScoreBoard from './JeopardyScoreboard'
import axios from 'axios'

function Jeopardy() {
    const [input, setInput] = useState('')
    const [question, setQuestion] = useState({})
    const [score, setScore] = useState(0)

    const controller = new AbortController()
    const signal = controller.signal

    const getNewQuestion = () => {
        axios.get('https://jservice.xyz/api/random-clue', { signal: signal }).then(result => {
            console.log(result.data)
            setQuestion(result.data)
        })
    }

    useEffect(() => {

        getNewQuestion()

        // runs when component is UNMOUNTED
        return () => {
            controller.abort()
        }
    }, [score])

    const onSubmit = (event) => {
        event.preventDefault()
        if(input.toLowerCase() === question.answer.toLowerCase()) {
            alert("YOU'RE RIGHT")
            setScore(score + question.value)
        } else {
            alert("YOU'RE WRONG")
            setScore(score - question.value)
        }
        setInput('')
    }

    return (
        <div>

            <JeopardyScoreBoard score={score} question={question}/>

            <form onSubmit={onSubmit}>
                <input value={input} onChange={(event) => setInput(event.target.value)} />

                <button>answer</button>
            </form>

            <button onClick={getNewQuestion}>skip</button>
            
        </div>
    )
}

export default Jeopardy