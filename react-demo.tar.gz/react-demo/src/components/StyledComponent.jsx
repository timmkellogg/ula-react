import styles from '../styles/StyledComponent.module.css'
import Button from 'react-bootstrap/Button'

function StyledComponent() {

    return (
        <div>
            <h3 className={styles.styledHeading}>Styled Component</h3>
            <Button variant='secondary'>text</Button>
        </div>
    )
}

export default StyledComponent