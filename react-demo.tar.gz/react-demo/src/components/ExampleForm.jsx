import { useState } from 'react'

function ExampleForm() {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        size: undefined,
        likesMushrooms: false,
        likesPineapple: false
    })

    const submitForm = (event) => {
        event.preventDefault()

        console.log(formData)
    }

    const handleChange = (event) => {
        const { name, value, type, checked } = event.target
       

        // if type === radio 
        setFormData({...formData, [name]: type === 'checkbox' ? checked : value })

    }

    return (
        <form onSubmit={submitForm}>
            <h3>Example Form</h3>

            <div>
                <input placeholder='First Name' name='firstName' value={formData.firstName} onChange={handleChange} />
                <input placeholder='Last Name' name='lastName' value={formData.lastName} onChange={handleChange} />
            </div>
            <br/>
            <br/>
            <div>
                <input checked={formData.size === 'small'} name='size' value='small' onChange={handleChange} type='radio' /><label>Small</label>

                <input checked={formData.size === 'medium'} name='size' value='medium' onChange={handleChange} type='radio' /><label>Medium</label>

                <input checked={formData.size === 'large'} name='size' value='large' onChange={handleChange} type='radio' /><label>Large</label>
            </div>

            <br />

            <div>
                <input type='checkbox' name='likesMushrooms' onChange={handleChange} />
                <label>Likes mushrooms</label>
            </div>

            <div>
                <input type='checkbox' name='likesPineapple' onChange={handleChange} />
                <label>Likes pineapple</label>
            </div>

            <br/>
            <button>Submit</button>
            
        </form>
    )
}

export default ExampleForm