import { useState } from 'react'

const Counter = () => {
    const [count, setCount] = useState(0)
    const [step, setStep] = useState(1)

    const handleIncrement = () => {
        setCount(count + Number(step))
    }

    const handleDecrement = () => {
        setCount(count - parseFloat(step))
    }

    return (
        <div>
            <h2>Count: {count}</h2>
            <input type='number' value={step} onChange={(event) => setStep(event.target.value)} />
            <button onClick={handleIncrement}>Increment</button>
            <button onClick={handleDecrement}>Decrement</button>
        </div>
    )
}

export default Counter