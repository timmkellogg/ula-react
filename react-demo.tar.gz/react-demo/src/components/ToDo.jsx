function ToDo({ item, toggleToDo, deleteToDo, index }) {
    return (
        <li style={{ textDecoration: item.completed ? 'line-through' : undefined }} onClick={() => toggleToDo(index)}>
            {item.text}
            <button onClick={(event) => deleteToDo(event, index)}>remove</button>
        </li>
    )
}

export default ToDo