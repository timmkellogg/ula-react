import { Navbar, Nav,Container } from 'react-bootstrap'
import { Link } from 'react-router-dom'

function ResponsiveAppBar() {

  return (
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container fluid>
        <Navbar.Brand href="#home">React + JWT</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">

            <Nav.Link to='/' as={Link}>Home</Nav.Link>

            <Nav.Link to='/todo-list' as={Link}>To Do List</Nav.Link>

            <Nav.Link to='/jeopardy' as={Link}>Jeopardy</Nav.Link>

            <Nav.Link to='/counter' as={Link}>Counter</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default ResponsiveAppBar
