import { useState } from 'react'
import { createBrowserRouter, RouterProvider, Outlet } from 'react-router-dom'
import UserContext from './contexts/UserContext'

import Counter from './components/Counter'
import ToDoList from './components/ToDoList'
import ExampleForm from './components/ExampleForm'
import StyledComponent from './components/StyledComponent'
import Jeopardy from './components/Jeopardy'
import Navbar from './components/Navbar'

import 'bootstrap/dist/css/bootstrap.min.css'

const Layout = () => {
  return (
    <>
      <Navbar />
      <Outlet />
    </>
  )
}

const App = () => {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          path: '/jeopardy',
          element: <Jeopardy />
        },
        {
          path: '/todo-list',
          element: <ToDoList />
        },
        {
          path: '/counter',
          element: <Counter />
        }
      ]
    }
  ])

  const user = {
    employeeID: 12345,
    username: 'tim',
    darkMode: true,

  }

  return (
    <UserContext.Provider value={user}>
      {/* <h1 className='styled-heading'>Vite + React</h1> */}
      {/* <ToDoList name='Tim' weather={weather} toDos={toDos} /> */}
      {/* <Counter /> */}
      {/* {<ExampleForm />} */}
      {/* <StyledComponent /> */}
      {/* <Jeopardy  /> */}
      <RouterProvider router={router} />
    </UserContext.Provider>
  )
}

export default App
